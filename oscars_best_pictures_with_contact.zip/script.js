
const initialMovies = [
  { title: "Nomadland (2020)", image: "https://image.tmdb.org/t/p/w500/8ho0sfp6XC4h3R2fGEl8ecVCLLj.jpg" },
  { title: "CODA (2021)", image: "https://image.tmdb.org/t/p/w500/Fl0sqaVP5vR4FQOghy7PkYc8iTo.jpg" },
  { title: "Everything Everywhere All at Once (2022)", image: "https://image.tmdb.org/t/p/w500/3Rr0JJG0T2WdgyQMFgC2mphgKdX.jpg" },
  { title: "Oppenheimer (2023)", image: "https://image.tmdb.org/t/p/w500/5l4V0hC3S9s6Bx7uR7S8IyfX2nQ.jpg" },
  { title: "Anora (2024)", image: "https://via.placeholder.com/300x450?text=Anora" },
  { title: "Titanic (1997)", image: "https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg" },
  { title: "The Lord of the Rings: The Return of the King (2003)", image: "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg" },
  { title: "Parasite (2019)", image: "https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg" }
];

function loadInitialMovies() {
  const gallery = document.getElementById("movieGallery");
  initialMovies.forEach(m => gallery.appendChild(createMovieCard(m.title, m.image)));
}

function addMovie() {
  const t = document.getElementById("movieTitle").value.trim();
  const u = document.getElementById("movieImage").value.trim();
  if (!t || !u) { alert("Enter title + image URL"); return; }
  document.getElementById("movieGallery").appendChild(createMovieCard(t, u));
  document.getElementById("movieTitle").value = "";
  document.getElementById("movieImage").value = "";
}

function createMovieCard(title, url) {
  const c = document.createElement("div"); c.className="movie-card";
  c.innerHTML = `<img src="${url}" alt="${title}"><h4>${title}</h4>
    <button onclick="removeMovie(this)">Remove</button>`;
  return c;
}

function removeMovie(btn) { btn.parentElement.remove(); }

window.onload = loadInitialMovies;

// Contact Form Validation
document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  const msg = document.getElementById("formMsg");

  if (!name || !email || !message) {
    msg.textContent = "Please fill in all fields.";
    msg.style.color = "red";
    return;
  }

  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!emailPattern.test(email)) {
    msg.textContent = "Enter a valid email.";
    msg.style.color = "red";
    return;
  }

  msg.textContent = "Message sent successfully!";
  msg.style.color = "green";
  document.getElementById("contactForm").reset();
});
